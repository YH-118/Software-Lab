package com.example.weather_hw;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;

import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

//
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;


public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        showName();
        showAddress();
    }


    private static final String location = "";
    private StringBuffer content = new StringBuffer();

    public void showName(){
        TextView show_name = findViewById(R.id.textView);

        String name = getIntent().getStringExtra(location);

        show_name.setText(name);
    }

    public void showAddress(){
        try {
            //strong of url
            URL url = new URL("https://maps.googleapis.com/maps/api/geocode/json?address=1600+Amphitheatre+Parkway,+Mountain+View,+CA&key=AIzaSyAMvgFTUfg1brfjS5IUQ0d7d7UHTjI1ICg");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");

            int status = con.getResponseCode();
            BufferedReader in;
            if(status > 299) {
                in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            }else{
                in = new BufferedReader(new InputStreamReader(con.getErrorStream()));
            }
            String inputline;

            while ((inputline = in.readLine())!=null){

                content.append(inputline);
            }
            in.close();
            con.disconnect();

        }catch(Exception e){
            System.out.println("connection error");
        }

        TextView show_msg = findViewById(R.id.msgView);

        show_msg.setText(content);

    }


    public class MapViewActivity extends AppCompatActivity implements OnMapReadyCallback {
        private MapView mapView;
        private GoogleMap gmap;

        private static final String MAP_VIEW_BUNDLE_KEY = "MapViewBundleKey";

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main2);

            Bundle mapViewBundle = null;
            if (savedInstanceState != null) {
                mapViewBundle = savedInstanceState.getBundle(MAP_VIEW_BUNDLE_KEY);
            }

            mapView = findViewById(R.id.mapView);
            mapView.onCreate(mapViewBundle);
            mapView.getMapAsync(this);
        }
        @Override
        public void onSaveInstanceState(Bundle outState) {
            super.onSaveInstanceState(outState);

            Bundle mapViewBundle = outState.getBundle(MAP_VIEW_BUNDLE_KEY);
            if (mapViewBundle == null) {
                mapViewBundle = new Bundle();
                outState.putBundle(MAP_VIEW_BUNDLE_KEY, mapViewBundle);
            }

            mapView.onSaveInstanceState(mapViewBundle);
        }
        @Override
        protected void onResume() {
            super.onResume();
            mapView.onResume();
        }

        @Override
        protected void onStart() {
            super.onStart();
            mapView.onStart();
        }

        @Override
        protected void onStop() {
            super.onStop();
            mapView.onStop();
        }
        @Override
        protected void onPause() {
            mapView.onPause();
            super.onPause();
        }
        @Override
        protected void onDestroy() {
            mapView.onDestroy();
            super.onDestroy();
        }
        @Override
        public void onLowMemory() {
            super.onLowMemory();
            mapView.onLowMemory();
        }
        @Override
        public void onMapReady(GoogleMap googleMap) {
            gmap = googleMap;
            gmap.setMinZoomPreference(12);
            LatLng ny = new LatLng(40.7143528, -74.0059731);
            gmap.moveCamera(CameraUpdateFactory.newLatLng(ny));
        }
    }


    MapViewActivity mva = new MapViewActivity();
    mva.onMapReady
    double lat = 37.4224494;
    double lon = -122.0845499;


}
