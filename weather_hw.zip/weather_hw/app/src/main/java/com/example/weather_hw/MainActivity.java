package com.example.weather_hw;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    private static final String location = "";


    public void parseName (View view) {
        Intent nameIntent = new Intent(this, Main2Activity.class);

        EditText text = (EditText)findViewById(R.id.editText);

        String name = text.getText().toString();

        nameIntent.putExtra(location,name); //string name, string value

        startActivity(nameIntent);
    }

}
